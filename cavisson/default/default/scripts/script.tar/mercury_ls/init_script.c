/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: cavisson
    Date of recording: 09/01/2021 12:51:09
    Flow details:
    Build details: 4.6.1 (build# 55)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
